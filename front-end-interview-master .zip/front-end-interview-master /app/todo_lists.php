<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class todo_lists extends Model
{
    //
}
